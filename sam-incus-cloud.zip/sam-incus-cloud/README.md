# SAM Incus Cloud

Discord-first Incus VPS control-plane starter for Debian 13 / Ubuntu 24.04.

## Included
- Discord slash-command bot (`/ping`, `/nodes`, `/instance`, `/create-container`, `/instance-action`)
- FastAPI health endpoint
- PostgreSQL + SQLAlchemy models and Alembic-ready schema bootstrap
- Redis-backed Celery worker
- Incus HTTPS client using client certificates
- Configuration validation, structured logging, Docker Compose
- Example environment file and installation helper

## Important scope and safety
This is a runnable foundation, **not** a completed commercial hosting platform. Billing, automated UPI verification, customer wallet ledger, robust multi-node scheduling, snapshots/backups, SSHX/tmate lifecycle management, IPAM, and full customer RBAC are not yet production implementations. Do not sell VPS plans or expose this to customers until those modules and the security checklist are completed.

The bot deliberately does not expose arbitrary shell execution or unrestricted Incus configuration. Use a private management network and a restricted Incus certificate. Never expose the Incus API publicly.

## Requirements
- Debian 13 or Ubuntu 24.04 host for the controller
- Docker Engine + Compose plugin
- A Discord application/bot token and application commands enabled
- One or more Incus nodes reachable over a private network
- Incus HTTPS API enabled with a trusted client certificate

## Quick start
1. Copy `.env.example` to `.env` and fill in the required values.
2. Put the Incus client certificate and key in `secrets/` (see `docs/INCUS.md`).
3. Run `chmod +x scripts/*.sh && ./scripts/install.sh`.
4. Check `docker compose logs -f bot api worker`.
5. In Discord, use `/ping`, then `/nodes`.

The starter `/create-container` command is owner-only and disabled unless `ENABLE_PROVISIONING=true`. It creates a minimal unprivileged container from a configured image alias. Test only on a disposable Incus node first.

## Services
- `bot`: Discord application
- `api`: FastAPI health/API service
- `worker`: Celery worker
- `scheduler`: Celery beat
- `postgres`: database
- `redis`: broker/cache

## Useful commands
```bash
docker compose up -d --build
docker compose logs -f bot
docker compose ps
docker compose down
docker compose down        # preserves named database volume
docker compose down -v     # DELETES database data; do not use casually
```

## Security checklist before production
- Restrict node API to VPN/private management network.
- Use Incus TLS client certificates with minimum required trust.
- Keep `.env` and `secrets/` out of Git.
- Rotate Discord token and API secrets if exposed.
- Add per-customer authorization and audit review before enabling customer commands.
- Implement payment provider webhooks with signature verification and idempotency.
- Add backup/restore tests and incident recovery procedures.
- Set resource quotas at Incus project/pool level, not only in application logic.
- Run the test suite and security review before production.
