# Installation on Debian 13

## 1. Prepare host
Use a clean Debian 13 or Ubuntu 24.04 controller VPS. Recommended starting point: 2 vCPU, 4 GB RAM, 30 GB disk for a small test deployment. Increase capacity for larger deployments.

Update packages:
```bash
sudo apt update && sudo apt -y upgrade
sudo apt install -y ca-certificates curl git openssl
```

## 2. Install Docker
Follow the official Docker Engine installation guide for your OS:
https://docs.docker.com/engine/install/debian/
Install the Docker Compose plugin too. Verify:
```bash
docker --version
docker compose version
```

## 3. Upload and extract
Upload `sam-incus-cloud.zip` to your controller, then:
```bash
sudo mkdir -p /opt
sudo unzip sam-incus-cloud.zip -d /opt/
cd /opt/sam-incus-cloud
```
If extracted into a nested folder, `cd` into the directory containing `docker-compose.yml`.

## 4. Generate configuration
```bash
chmod +x scripts/*.sh
./scripts/install.sh
```
The first run creates `.env` and generates secrets. Edit it:
```bash
nano .env
```
Set:
- `DISCORD_TOKEN`
- `DISCORD_OWNER_ID` (your numeric Discord user ID)
- `DISCORD_GUILD_ID` (optional; recommended for quick guild command sync)
- `INCUS_NODES_JSON`
- Keep `ENABLE_PROVISIONING=false` initially.

Set `DB_PASSWORD` to the same generated value used in `DATABASE_URL` and `SYNC_DATABASE_URL`. The installer replaces the DB placeholder in the URLs, but Docker Compose also requires `DB_PASSWORD`; add a line `DB_PASSWORD=the_same_password` to `.env`.

## 5. Configure Incus certificates
Follow `docs/INCUS.md`. Put all three certificate files into `secrets/`. Ensure the Incus node is reachable over the private network.

## 6. Start
```bash
./scripts/install.sh
docker compose ps
docker compose logs -f bot
```

## 7. Verify Discord
Invite the bot with `bot` and `applications.commands` scopes and appropriate permissions to send messages and use application commands. Use `/ping` and `/nodes`.

## 8. Enable test provisioning
Only after `/nodes` succeeds and you have tested permissions on a disposable node:
```bash
nano .env
# set ENABLE_PROVISIONING=true
docker compose up -d --build
```
Use `/create-container` only for a test container.

## 9. Update
```bash
git pull
docker compose up -d --build
```
For a ZIP-based install, replace the project files with the new release and retain `.env` and `secrets/`.

## 10. Troubleshooting
```bash
docker compose ps
docker compose logs --tail=200 bot
docker compose logs --tail=200 api
docker compose logs --tail=200 worker
docker compose logs --tail=200 postgres
```
Do not post `.env`, private keys, Discord tokens, or payment secrets in support chats.
