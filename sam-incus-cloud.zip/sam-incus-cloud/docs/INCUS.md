# Connecting an Incus node

## Network
- Connect controller and Incus node using Tailscale, NetBird, WireGuard or another private management network.
- Permit TCP 8443 only from the controller's private address.
- Do not port-forward 8443 from the public internet.
- The controller's configured URL must use the node's private VPN address and HTTPS.

## Enable Incus HTTPS API
On the Incus node, follow the official Incus documentation for configuring the HTTPS server and trust certificates:
https://linuxcontainers.org/incus/docs/main/server/

Create a dedicated client certificate for the controller and add that certificate to the Incus trust store. Use the least privileged trust role supported by your Incus version and test permissions. Do not blindly grant unrestricted admin access to a public-facing bot.

Copy these files to the controller project:
- `secrets/incus_client.crt`
- `secrets/incus_client.key`
- `secrets/incus_server_ca.crt`

Protect the private key:
```bash
chmod 700 secrets
chmod 600 secrets/incus_client.key
chmod 644 secrets/incus_client.crt secrets/incus_server_ca.crt
```

Set `INCUS_NODES_JSON` in `.env`, replacing the sample VPN IP:
```json
[{"name":"node-01","url":"https://100.64.0.10:8443","project":"default","client_cert":"/run/secrets/incus_client.crt","client_key":"/run/secrets/incus_client.key","server_ca":"/run/secrets/incus_server_ca.crt"}]
```

The Compose secret names are mounted at `/run/secrets/...` inside bot and worker containers.

## First test
Keep `ENABLE_PROVISIONING=false`. Start the stack and use `/nodes` as the bot owner. Confirm TLS and authorization are correct before enabling any provisioning.

## Container test
After validating the API permissions, set `ENABLE_PROVISIONING=true`. The sample create command uses fixed safe defaults (unprivileged container, 1 CPU, 1 GiB RAM). It is for controlled testing, not a customer-ready order workflow.
