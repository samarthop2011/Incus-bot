# Implementation roadmap

## Included in starter
- Bot startup and slash command sync
- Owner-gated node health command
- Incus mutual-TLS client
- Owner-gated test container creation
- Instance action command with owner binding
- FastAPI health endpoint
- PostgreSQL starter models
- Redis/Celery service scaffold
- Compose deployment

## Not yet production implemented
- KVM provisioning and cloud-init
- Multi-node capacity scheduler and atomic reservations
- Customer signup, plan catalogue, orders and subscription state machine
- Wallet ledger and payment provider integration
- UPI gateway webhook signature verification
- SSH key injection/rotation and password reset
- tmate self-hosted server deployment and session lifecycle
- SSHX session lifecycle and link secrecy
- ttyd authenticated proxy
- IPAM, firewall and Cloudflare DNS
- Snapshot/backup export, retention and restore workflows
- Resource metrics and alerting
- Tickets, coupons, referrals, invoices
- Full RBAC, audit coverage, rate limits and security tests
- Alembic migrations, backup automation and disaster recovery

Do not describe this starter as production-ready until the above are implemented, tested and reviewed.
