from app.worker.celery_app import celery_app

@celery_app.task(name="samcloud.healthcheck")
def healthcheck():
    return {"status": "ok"}
