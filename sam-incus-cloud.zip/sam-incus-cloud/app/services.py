from app.config import get_settings
from app.incus_client import IncusClient

async def node_health():
    results = []
    for node in get_settings().incus_nodes:
        client = IncusClient(node)
        try:
            info = await client.server_info()
            results.append({"node": node.name, "ok": True, "api": info.get("metadata", {})})
        except Exception as exc:
            results.append({"node": node.name, "ok": False, "error": str(exc)[:300]})
        finally:
            await client.close()
    return results

def get_node(name: str):
    for node in get_settings().incus_nodes:
        if node.name == name:
            return node
    raise ValueError("Unknown node")
