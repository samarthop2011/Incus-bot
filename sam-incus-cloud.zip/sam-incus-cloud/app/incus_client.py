import httpx
from app.config import NodeConfig

class IncusError(RuntimeError):
    pass

class IncusClient:
    """Small HTTPS Incus client. Node API must only be reachable over a private network."""
    def __init__(self, node: NodeConfig):
        self.node = node
        self.client = httpx.AsyncClient(
            base_url=node.url.rstrip("/") + "/1.0",
            cert=(node.client_cert, node.client_key),
            verify=node.server_ca,
            timeout=httpx.Timeout(30.0, connect=10.0),
        )

    async def close(self):
        await self.client.aclose()

    async def request(self, method: str, path: str, **kwargs):
        response = await self.client.request(method, path, **kwargs)
        response.raise_for_status()
        payload = response.json()
        if payload.get("type") == "error" or payload.get("error_code", 0):
            raise IncusError(payload.get("error", "Incus API error"))
        return payload

    async def server_info(self):
        return await self.request("GET", "")

    async def list_instances(self):
        return await self.request("GET", "/instances")

    async def create_container(self, name: str, source: str, project: str):
        if not name.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Invalid instance name")
        config = {
            "name": name,
            "type": "container",
            "source": {"type": "image", "alias": source},
            "config": {
                "security.privileged": "false",
                "limits.cpu": "1",
                "limits.memory": "1GiB"
            },
            "start": True,
        }
        return await self.request("POST", "/instances", params={"project": project}, json=config)

    async def instance_action(self, name: str, action: str, project: str):
        allowed = {"start", "stop", "restart", "freeze", "unfreeze"}
        if action not in allowed:
            raise ValueError("Unsupported instance action")
        return await self.request(
            "PUT", f"/instances/{name}/state",
            params={"project": project},
            json={"action": action, "timeout": 30, "force": False},
        )
