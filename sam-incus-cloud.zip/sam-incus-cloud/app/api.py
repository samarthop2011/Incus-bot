from fastapi import FastAPI, Header, HTTPException
from app.config import get_settings
from app.services import node_health
from app.db import init_db

app = FastAPI(title="SAM Incus Cloud API", version="0.1.0")

@app.on_event("startup")
async def startup():
    await init_db()

@app.get("/health")
async def health():
    return {"status": "ok", "service": "sam-incus-cloud"}

@app.get("/nodes/health")
async def nodes_health(x_api_secret: str | None = Header(default=None)):
    if not x_api_secret or x_api_secret != get_settings().api_secret:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return await node_health()
