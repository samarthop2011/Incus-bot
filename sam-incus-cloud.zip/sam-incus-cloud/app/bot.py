import asyncio
import discord
from discord import app_commands
from discord.ext import commands
from sqlalchemy import select
from app.config import get_settings
from app.db import init_db, SessionLocal
from app.models import Instance, AuditLog
from app.services import node_health, get_node
from app.incus_client import IncusClient
from app.logging_config import configure_logging
import structlog

settings = get_settings()
configure_logging(settings.log_level)
log = structlog.get_logger()

intents = discord.Intents.none()
bot = commands.Bot(command_prefix="!", intents=intents)

def is_owner(interaction: discord.Interaction) -> bool:
    return interaction.user.id == settings.discord_owner_id

@bot.event
async def on_ready():
    await init_db()
    if settings.discord_guild_id:
        guild = discord.Object(id=settings.discord_guild_id)
        bot.tree.copy_global_to(guild=guild)
        await bot.tree.sync(guild=guild)
    else:
        await bot.tree.sync()
    log.info("bot_ready", user=str(bot.user))

@bot.tree.command(name="ping", description="Check SAM Incus Cloud bot status")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message("SAM Incus Cloud is online.", ephemeral=True)

@bot.tree.command(name="nodes", description="Check configured Incus node health (owner only)")
async def nodes(interaction: discord.Interaction):
    if not is_owner(interaction):
        return await interaction.response.send_message("Not authorized.", ephemeral=True)
    await interaction.response.defer(ephemeral=True, thinking=True)
    results = await node_health()
    lines = [f"{'🟢' if x['ok'] else '🔴'} **{x['node']}**: {'online' if x['ok'] else x['error']}" for x in results]
    await interaction.followup.send("\n".join(lines) if lines else "No nodes configured.", ephemeral=True)

@bot.tree.command(name="create-container", description="Create a test container (owner only)")
@app_commands.describe(node="Configured node name", name="Unique instance name", image="Incus image alias")
async def create_container(interaction: discord.Interaction, node: str, name: str, image: str = ""):
    if not is_owner(interaction):
        return await interaction.response.send_message("Not authorized.", ephemeral=True)
    if not settings.enable_provisioning:
        return await interaction.response.send_message("Provisioning is disabled. Set ENABLE_PROVISIONING=true after testing.", ephemeral=True)
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        cfg = get_node(node)
        client = IncusClient(cfg)
        try:
            result = await client.create_container(name, image or settings.default_container_image, cfg.project)
        finally:
            await client.close()
        async with SessionLocal() as db:
            db.add(Instance(owner_discord_id=interaction.user.id, node_name=node,
                            incus_name=name, kind="container",
                            image=image or settings.default_container_image, status="provisioning"))
            db.add(AuditLog(actor_discord_id=interaction.user.id, action="create_container", target=name))
            await db.commit()
        await interaction.followup.send(f"Create request accepted for `{name}`. Incus response: `{result.get('type', 'operation')}`", ephemeral=True)
    except Exception as exc:
        log.exception("container_create_failed", node=node, instance=name)
        await interaction.followup.send(f"Creation failed: `{str(exc)[:700]}`", ephemeral=True)

@bot.tree.command(name="instance-action", description="Start, stop or restart one of your registered instances")
@app_commands.describe(name="Instance name", action="Action to perform")
@app_commands.choices(action=[
    app_commands.Choice(name="start", value="start"),
    app_commands.Choice(name="stop", value="stop"),
    app_commands.Choice(name="restart", value="restart"),
])
async def instance_action(interaction: discord.Interaction, name: str, action: app_commands.Choice[str]):
    async with SessionLocal() as db:
        row = await db.scalar(select(Instance).where(
            Instance.incus_name == name,
            Instance.owner_discord_id == interaction.user.id
        ))
    if not row and not is_owner(interaction):
        return await interaction.response.send_message("Instance not found or not yours.", ephemeral=True)
    if not row:
        return await interaction.response.send_message("Instance is not registered in the starter database.", ephemeral=True)
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        cfg = get_node(row.node_name)
        client = IncusClient(cfg)
        try:
            result = await client.instance_action(name, action.value, cfg.project)
        finally:
            await client.close()
        await interaction.followup.send(f"`{action.value}` requested for `{name}`. Operation: `{result.get('type', 'accepted')}`", ephemeral=True)
    except Exception as exc:
        await interaction.followup.send(f"Operation failed: `{str(exc)[:700]}`", ephemeral=True)

def main():
    if not settings.discord_token:
        raise SystemExit("DISCORD_TOKEN is missing. Configure .env.")
    bot.run(settings.discord_token)

if __name__ == "__main__":
    main()
