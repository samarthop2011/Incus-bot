import json
from functools import lru_cache
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class NodeConfig(BaseModel):
    name: str
    url: str
    project: str = "default"
    client_cert: str
    client_key: str
    server_ca: str

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_env: str = "development"
    log_level: str = "INFO"
    app_secret: str = Field(min_length=24)
    api_secret: str = Field(min_length=24)
    discord_token: str = ""
    discord_owner_id: int = 0
    discord_guild_id: int | None = None
    database_url: str
    sync_database_url: str
    redis_url: str
    incus_nodes_json: str = "[]"
    enable_provisioning: bool = False
    default_container_image: str = "images:debian/13"

    @property
    def incus_nodes(self) -> list[NodeConfig]:
        try:
            return [NodeConfig.model_validate(x) for x in json.loads(self.incus_nodes_json)]
        except Exception as exc:
            raise ValueError(f"Invalid INCUS_NODES_JSON: {exc}") from exc

@lru_cache
def get_settings() -> Settings:
    return Settings()
