#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is missing. Install Docker Engine and the Compose plugin first."
  echo "Official guide: https://docs.docker.com/engine/install/debian/"
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose plugin is missing."
  exit 1
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  DB_PASS="$(openssl rand -hex 24)"
  sed -i "s/CHANGE_DB_PASSWORD/${DB_PASS}/g" .env
  printf "\nDB_PASSWORD=%s\n" "$DB_PASS" >> .env
  sed -i "s/CHANGE_ME_TO_A_LONG_RANDOM_SECRET/$(openssl rand -hex 32)/" .env
  sed -i "s/CHANGE_ME_TO_ANOTHER_LONG_RANDOM_SECRET/$(openssl rand -hex 32)/" .env
  echo
  echo "Created .env with generated database and application secrets."
  echo "Edit .env now and add DISCORD_TOKEN, owner ID and Incus node details."
  echo "Then run this script again."
  exit 0
fi

mkdir -p secrets
for f in incus_client.crt incus_client.key incus_server_ca.crt; do
  if [[ ! -s "secrets/$f" ]]; then
    echo "Missing secrets/$f. Follow docs/INCUS.md before starting."
    exit 1
  fi
done

docker compose config >/dev/null
docker compose up -d --build
echo "SAM Incus Cloud services started."
echo "Check: docker compose ps"
echo "Logs:  docker compose logs -f bot"
