def test_project_package_name():
    import app
    assert app is not None
